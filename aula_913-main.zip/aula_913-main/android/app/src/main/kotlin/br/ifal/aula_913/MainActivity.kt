package br.ifal.aula_913

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
